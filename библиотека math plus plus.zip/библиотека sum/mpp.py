from random import randint

def plus (a, b):
	return a + b

def minus (a, b):
	return a - b
	
def umnogh (a, b):
	return a * b
	
def razdelit (a, b):
	return a / b

def r_int(a, b):
	result = randint(a, b)
	return result
	
